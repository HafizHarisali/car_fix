<link rel="icon" type="image/icon" href="images/favicon/favicon.ico"> <!-- favicon-icon -->
<!-- theme style -->
<link href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/> <!-- bootstrap css -->
<link href="<?php echo e(asset('public/assets/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css"/> <!-- fontawesome css -->
<link href="<?php echo e(asset('public/assets/css/icon-font.css')); ?>" rel="stylesheet" type="text/css"/> <!-- icon-font css -->
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700|Poppins:400,500,700" rel="stylesheet"> <!-- google font -->
<link href="<?php echo e(asset('public/assets/css/menumaker.css')); ?>" rel="stylesheet" type="text/css"/> <!-- menu css -->
<link href="<?php echo e(asset('public/assets/css/owl.carousel.css')); ?>" rel="stylesheet" type="text/css"/> <!-- owl carousel css -->
<link href="<?php echo e(asset('public/assets/css/magnific-popup.css')); ?>" rel="stylesheet" type="text/css"/> <!-- magnify popup css -->
<link href="<?php echo e(asset('public/assets/css/datepicker.css')); ?>" rel="stylesheet" type="text/css"/> <!-- datepicker css -->
<link href="<?php echo e(asset('public/assets/css/style.css')); ?>" rel="stylesheet" type="text/css"/> <!-- custom css --><?php /**PATH C:\xampp\htdocs\car_fix\resources\views/front/includes/style.blade.php ENDPATH**/ ?>