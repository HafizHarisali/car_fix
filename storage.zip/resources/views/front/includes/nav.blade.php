<!--  navigation -->
  <div class="nav-bar">
    <div class="container">
      <div class="row">
        <div class="col-sm-4">
          <div class="logo">
            <a href="{{ route('index') }}"><img src="{{ asset('public/assets/images/logo.png') }}" alt="logo"></a>
          </div>
        </div>
        <div class="col-sm-8">
          <div class="navigation">
            <div id="cssmenu">
              <ul>
                <li><a href="{{ route('index') }}">Home</a>
                  
                </li>                
                <li><a href="#">Pages</a>
                  
                </li>
                <li><a href="#">Services</a>
                 
                </li>                
                <li><a href="#">Gallery</a>
                  
                </li>
                 <li><a href="#">Team</a>
                  
                </li>
                <li><a href="#">Blog</a>
                  
                </li>        
                <li><a href="#">Shop</a>
                  
                </li>       
                <li><a href="#">Contact</a>
                  
                </li>
              </ul>
            </div>
          </div>
        </div>        
      </div>
    </div>
  </div> 
<!--  end navigation -->